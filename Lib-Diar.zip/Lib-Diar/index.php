<?php
	header("Location:homepage/index.php");
	 exit;

?>